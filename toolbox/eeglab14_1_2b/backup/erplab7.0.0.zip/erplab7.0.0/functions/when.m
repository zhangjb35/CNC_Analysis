function when
disp('Are you bored?')