fprintf([repmat('-', 1,100) '\n'])
cprintf([0.1333    0.5451    0.1333], '%%Equivalent command:\n');
fprintf('%s\n', erpcom);
fprintf([repmat('-', 1,100) '\n'])